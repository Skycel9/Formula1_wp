<?php

namespace ms\api\class;

class Routes {
	public string $method;
	public string $route;
	
	function __construct($method = "GET") {
		if ($this->isValidMethod($method)) {
			$this->method = $method;
		} else {
			throw new \Error("This method is not valid, please use one of these methods (GET, POST, PUT, DELETE)");
		}
		
		$this->route = strtolower(pathinfo(get_called_class(), PATHINFO_FILENAME));
		
	}
	
	public function defaultPost($post) {
		return array(
			"id"=> $post->ID,
			"slug"=> $post->post_name,
			"type"=> $post->post_type,
			"title"=> $post->post_title,
			"content"=> $post->post_content,
			"excerpt"=> $post->post_excerpt,
			"date"=> $post->post_date,
			"date_gmt"=> $post->post_date_gmt,
			"modified"=> $post->post_modified,
			"modified_gmt"=> $post->post_modified_gmt,
			"status"=> $post->post_status,
			"parent"=> $post->post_parent,
			"guid"=> $post->guid,
			"author"=> $post->post_author,
		);
	}
	
	private function isValidMethod($method): bool {
		return in_array($method, ["GET", "POST", "PUT", "DELETE"]);
	}
}