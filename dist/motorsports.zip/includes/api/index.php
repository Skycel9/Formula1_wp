<?php

// Allow loading necessary files
require __DIR__ . "/autoload.php";

// Import all utilities for API plugin's part
include __DIR__ . "/utils/functions.php";


add_action("rest_api_init", function () {
	foreach (getRoutes() as $route) {
		register_rest_route("ms/v1", "/".$route->route, array(
			"methods"=> $route->method,
			"callback"=> function ($request) use ($route) {
				return $route->callback($request);
			},
			"permission_callback" => "__return_true",
			"args" => array(
				"per_page" => array(
					"validate_callback" => function($param, $request, $key) {
						return is_numeric($param);
					}
				),
				"page"=> array(
					"validate_callback" => function($param, $request, $key) {
                        return is_numeric($param);
                    }
				)
			),
		));
		
		register_rest_route("ms/v1", "/".$route->route . "/(?P<id>\d+)", array(
			"methods"=> $route->method,
			"callback"=> function ($request) use ($route) {
				return $route->callback($request);
			},
			"permission_callback" => "__return_true",
			"args" => array(
				"per_page" => array(
					"validate_callback" => function($param, $request, $key) {
						return is_numeric($param);
					}
				),
				"page"=> array(
					"validate_callback" => function($param, $request, $key) {
						return is_numeric($param);
					}
				)
			),
		));
	}
});