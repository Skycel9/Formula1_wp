<?php

spl_autoload_register(function ($class) {
	// Le namespace de base pour votre projet
	$prefix = 'ms\\api\\';
	
	
	// La base de répertoire pour le prefix de namespace
	$base_dir = __DIR__ . '/';
	
	// Est-ce que la class utilise le prefix de namespace ?
	$len = strlen($prefix);
	if (strncmp($prefix, $class, $len) !== 0) {
		// Non, donc on passe au prochain autoloader
		return;
	}
	
	// Obtenir le nom relatif de la class
	$relative_class = substr($class, $len);
	
	// Remplacer le namespace par le répertoire de base, remplacer les séparateurs de namespace par des séparateurs de répertoire, ajouter .php
	$file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
	
	// Si le fichier existe, le require
	if (file_exists($file)) {
		require $file;
	}
});