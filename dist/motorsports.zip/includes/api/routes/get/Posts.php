<?php

namespace ms\api\routes\get;

use ms\api\class\Routes;

class Posts extends Routes {
	public function __construct($method) {
		parent::__construct($method);
	}
	
	public function callback($request) {
		
		$args = array(
			"post_type"=> "post",
			"post_status"=> "publish",
            "posts_per_page"=> -1,
			"p"=> $request["id"] ?: null
		);
		
		$posts = get_posts($args);
		
		$arr = array();
		foreach ($posts as $post) {
			$arr[] = $this->defaultPost($post);
		}
		
		return $arr;
	}
}