<?php

namespace ms\api\routes\get;

use ms\api\class\Routes;

class Races extends Routes {
	public function __construct($method) {
		parent::__construct($method);
	}
	
	public function callback($request) {
		$args = array(
			"post_type"=> "race",
			"posts_per_page"=> -1,
			"p"=> $request["id"] ?: null
		);
		
		$posts = get_posts($args);
		
		$arr = array();
		foreach ($posts as $post) {
			$tracks = get_field("circuits", $post->ID);
			$arr[] = array_merge(
				$this->defaultPost($post),
				array("data"=>
				    array(
                        "nbEdition"=> get_field("nb_edition", $post->ID),
					    "tracks"=> (is_array($tracks) && count($tracks) > 0) ? array(
						    "ID"=> array_column(get_field("circuits", $post->ID),"ID"),
						    "type"=> array_unique(array_column(get_field("circuits", $post->ID),"post_type")) ? array_unique(array_column(get_field("circuits", $post->ID),"post_type"))[0] : null
					    ) : null,
					    "image"=> get_field("flag", $post->ID)["ID"]
                    )
				)
			);
		}
		
		return $arr;
	}
}