<?php

namespace ms\api\routes\get;

use ms\api\class\Routes;

class All extends Routes {
	public function __construct() {
		parent::__construct();
	}
	
	public function callback($request) {
		
		$args = array(
			"post_type"=> ["circuit", "race"],
			"post_status"=> "publish",
			"posts_per_page"=> -1,
			"p"=> $request["id"] ?: null
		);
		
		$posts = get_posts($args);
		
		$arr = array();
		foreach ($posts as $post) {
			if ($post->post_type === "circuit") {
				$arr[] = array_merge(
					$this->defaultPost($post),
					array("data"=>
						array(
							"place"=> get_field("place", $post->ID),
							"distance"=> get_field("distance", $post->ID),
							"track_type"=> get_field("track_type", $post->ID),
							"events"=> array(
								"ID"=> is_array(get_field("event", $post->ID)) ? array_column(get_field("event", $post->ID),"ID") : null,
								"type"=> is_array(get_field("event", $post->ID)) ? array_unique(array_column(get_field("event", $post->ID), "post_type"))[0] : null
							),
							"image"=> get_field("image", $post->ID)["ID"],
						)
					)
				);
			} else if ($post->post_type === "race") {
				$tracks = get_field("circuits", $post->ID);
				$arr[] = array_merge(
					$this->defaultPost($post),
					array("data"=>
						array(
							"nbEdition"=> get_field("nb_edition", $post->ID),
							"tracks"=> (is_array($tracks) && count($tracks) > 0) ? array(
								"ID"=> array_column(get_field("circuits", $post->ID),"ID"),
								"type"=> array_unique(array_column(get_field("circuits", $post->ID),"post_type")) ? array_unique(array_column(get_field("circuits", $post->ID),"post_type"))[0] : null
							) : null,
							"image"=> get_field("flag", $post->ID)["ID"]
						)
					)
				);
			}
		}
		
		return $arr;
	}
}