<?php
namespace ms\api\routes\get;

use ms\api\class\Routes;


class Tracks extends Routes {
	
	public function __construct($method) {
        parent::__construct($method);
    }
	
	public function callback($request): array {
		$params = array(
			"per_page"=> $request->get_param("per_page"),
			"page"=> $request->get_param("page")
		);
		
		$args = array(
            "post_type"=> "circuit",
			"posts_per_page"=> $params['per_page'],
			"paged"=> $params['page'],
			"p"=> $request["id"] ?: null
		);
		
		$posts = get_posts($args);
		
		$arr = array();
		foreach ($posts as $post) {
			$arr[] = array_merge(
				$this->defaultPost($post),
				array("data"=>
					array(
						"place"=> get_field("place", $post->ID),
	                    "distance"=> get_field("distance", $post->ID),
						"track_type"=> get_field("track_type", $post->ID),
						"events"=> array(
							"ID"=> is_array(get_field("event", $post->ID)) ? array_column(get_field("event", $post->ID),"ID") : null,
							"type"=> is_array(get_field("event", $post->ID)) ? array_unique(array_column(get_field("event", $post->ID), "post_type"))[0] : null
					),
						"image"=> get_field("image", $post->ID)["ID"],
					)
				)
			);
		}
		
		return $arr;
	}
}