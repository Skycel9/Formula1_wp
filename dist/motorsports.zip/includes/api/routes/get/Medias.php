<?php

namespace ms\api\routes\get;

use ms\api\class\Routes;

class Medias extends Routes {
	public function __construct($method) {
		parent::__construct($method);
	}
	
	public function callback($request) {
		
		$args = array(
			"post_type"=> "attachment",
			"posts_per_page"=> -1,
			"p"=> $request["id"]?: null,
		);
		
		$posts = get_posts($args);
		
		$arr = array();
		foreach ($posts as $post) {
			if ($post->post_mime_type === "image/svg+xml") {
				$image = array(
                    "url"=> wp_get_attachment_url($post->ID),
                    "alt"=> get_post_meta($post->ID, "_wp_attachment_image_alt", true),
                    "title"=> get_post_field("post_title", $post->ID));
            } else {
				$image = array(
					"url"=> wp_get_attachment_url($post->ID),
					"thumbnail"=> wp_get_attachment_image_src($post->ID, "thumbnail"),
					"medium"=> wp_get_attachment_image_src($post->ID, "medium"),
					"large"=> wp_get_attachment_image_src($post->ID, "large"),
					"full"=> wp_get_attachment_image_src($post->ID, "full"),
					"alt"=> get_post_meta($post->ID, "_wp_attachment_image_alt", true),
					"title"=> get_post_field("post_title", $post->ID));
			}
			$arr[] = array_merge(
				$this->defaultPost($post),
				array(
					"image"=> $image
				)
			);
		}
		
		return $arr;
	}
}