<?php
/**
 * Load every files in routes folder as API routes
 * @return array
 */
function getRoutes(): array {
	$files = parseDir(__DIR__ . "/../routes");
	
	$arr = array();
	foreach ($files as $file) {
		$method = strtoupper(basename(dirname($file)));
		$class_name = "ms\\api\\routes\\" . $method . "\\" .  pathinfo($file, PATHINFO_FILENAME);
		
		if (class_exists($class_name)) {
			$arr[] = new $class_name($method);
		}
    }
	
	return $arr;
}