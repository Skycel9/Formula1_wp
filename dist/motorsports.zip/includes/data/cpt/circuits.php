<?php
add_action( 'init', function() {
	register_post_type( 'circuit', array(
		'labels' => array(
			'name' => 'Circuits',
			'singular_name' => 'Circuit',
			'menu_name' => 'Circuits',
			'all_items' => 'Tout les Circuits',
			'edit_item' => 'Modifier Circuit',
			'view_item' => 'Voir Circuit',
			'view_items' => 'Voir Circuits',
			'add_new_item' => 'Ajouter Circuit',
			'add_new' => 'Ajouter Circuit',
			'new_item' => 'Nouveau Circuit',
			'parent_item_colon' => 'Circuit parent :',
			'search_items' => 'Rechercher Circuits',
			'not_found' => 'Aucun circuits trouvé',
			'not_found_in_trash' => 'No circuits found in Trash',
			'archives' => 'Archives des Circuit',
			'attributes' => 'Attributs des Circuit',
			'insert_into_item' => 'Insérer dans circuit',
			'uploaded_to_this_item' => 'Téléversé sur ce circuit',
			'filter_items_list' => 'Filtrer la liste circuits',
			'filter_by_date' => 'Filtrer circuits par date',
			'items_list_navigation' => 'Navigation dans la liste Circuits',
			'items_list' => 'Liste Circuits',
			'item_published' => 'Circuit publié.',
			'item_published_privately' => 'Circuit publié en privé.',
			'item_reverted_to_draft' => 'Circuit repassé en brouillon.',
			'item_scheduled' => 'Circuit planifié.',
			'item_updated' => 'Circuit mis à jour.',
			'item_link' => 'Lien Circuit',
			'item_link_description' => 'Un lien vers un circuit.',
		),
		'public' => true,
		'show_in_rest' => true,
		'menu_icon' => 'dashicons-admin-site-alt',
		'supports' => array(
			0 => 'title',
		),
		'delete_with_user' => false,
	) );
} );

