<?php
add_action( 'init', function() {
	register_post_type( 'team', array(
		'labels' => array(
			'name' => 'Teams',
			'singular_name' => 'Team',
			'menu_name' => 'Teams',
			'all_items' => 'Tout les Teams',
			'edit_item' => 'Modifier Team',
			'view_item' => 'Voir Team',
			'view_items' => 'Voir Teams',
			'add_new_item' => 'Ajouter Team',
			'add_new' => 'Ajouter Team',
			'new_item' => 'Nouveau Team',
			'parent_item_colon' => 'Team parent :',
			'search_items' => 'Rechercher Teams',
			'not_found' => 'Aucun teams trouvé',
			'not_found_in_trash' => 'No teams found in Trash',
			'archives' => 'Archives des Team',
			'attributes' => 'Attributs des Team',
			'insert_into_item' => 'Insérer dans team',
			'uploaded_to_this_item' => 'Téléversé sur ce team',
			'filter_items_list' => 'Filtrer la liste teams',
			'filter_by_date' => 'Filtrer teams par date',
			'items_list_navigation' => 'Navigation dans la liste Teams',
			'items_list' => 'Liste Teams',
			'item_published' => 'Team publié.',
			'item_published_privately' => 'Team publié en privé.',
			'item_reverted_to_draft' => 'Team repassé en brouillon.',
			'item_scheduled' => 'Team planifié.',
			'item_updated' => 'Team mis à jour.',
			'item_link' => 'Lien Team',
			'item_link_description' => 'Un lien vers un team.',
		),
		'public' => true,
		'show_in_rest' => true,
		'menu_icon' => 'dashicons-groups',
		'supports' => array(
			0 => 'title',
		),
		'delete_with_user' => false,
	) );
} );

