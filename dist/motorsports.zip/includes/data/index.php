<?php

/*$files = scandir(__DIR__ );

var_dump($files);
echo "<br><br>";

foreach ( $files as $file ) {
	if ($file !== '.' && $file !== '..') {
		if (is_dir(__DIR__ . "/" . $file)) {
			$subfiles = scandir(__DIR__ . "/" . $file);
			
			var_dump($subfiles);
		}
	}
}*/

$files = parseDir(__DIR__ . DIRECTORY_SEPARATOR . "cpt");

foreach ($files as $file) {
	include $file;
}