<?php
/**
 * Return an array of each files path in the given directory
 *
 * @param $dir string - Path to directory
 * @return array
 */
function parseDir($dir) {
	$files = array();
	
	$handle = opendir($dir);
	
	while (($file = readdir($handle)) !== false) {
	
		if ($file !== "." && $file !== "..") {
			$path = $dir . DIRECTORY_SEPARATOR . $file;
			
			if (is_dir($path)) {
				$files = array_merge($files, parseDir($path));
			} elseif (is_file($path) && pathinfo($file, PATHINFO_EXTENSION) === "php") {
				$files[] = $path;
			}
		}
	}
	
	closedir($handle);
	return $files;
}

/**
 * Return an array of each files in given directories
 * This function needs parseDir function
 *
 * @param $dirs
 * @return array
 *
 * @see parseDir()
 */
function parseDirs($dirs) {
	$files = array();
	foreach ($dirs as $dir) {
		foreach (parseDir($dir) as $file) {
			$files[] = $file;
		}
	}
	
	return $files;
}

function listerFichiersPHP($dossier) {
	
	// Parcourt tous les éléments du dossier
	while (false !== ($fichier = readdir($handle))) {
		// Ignore les dossiers "." et ".."
		if ($fichier != "." && $fichier != "..") {
			$chemin = $dossier . DIRECTORY_SEPARATOR . $fichier;
			// Si c'est un dossier, on répète la fonction pour ce dossier
			if (is_dir($chemin)) {
				$fichiersPHP = array_merge($fichiersPHP, listerFichiersPHP($chemin));
			} elseif (is_file($chemin) && pathinfo($fichier, PATHINFO_EXTENSION) === 'php') {
				// Si c'est un fichier PHP, on l'ajoute au tableau
				$fichiersPHP[] = $chemin;
			}
		}
	}
	
	// Ferme le dossier
	closedir($handle);
	
	return $fichiersPHP;
}