<?php
/*
 * Plugin Name: MotorSports plugin
 * Plugin URI: https://youtu.be/dQw4w9WgXcQ
 * Description: Plugin de distribution de données concernant les sports mécanique
 * Version: 0.1.0
 * Requires PHP: 7.4.33
 * Author: Skycel
 * Author URI: https://skycel.me/
 */

include_once "vendor/advanced-custom-fields-pro/acf.php";

// Import all utilities function for the whole plugin
include "assets/php/utils.php";

// Dead code
//include "includes/data/index.php";

// Include management API file
include "includes/api/index.php";

// Allow adding SVG images to WordPress media files
function ms_mime_types( $mimes ){
	$mimes['svg'] = 'image/svg+xml';
	return $mimes;
}
add_filter( 'upload_mimes', 'ms_mime_types' );

